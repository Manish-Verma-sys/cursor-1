﻿export type SolutionDetail = {
  title: string
  year: number
  country: string
  tag: string
  summary: string
  bullets: string[]
  paragraph: string
}
export type SolutionLeaf = { id: string; label: string; detail: SolutionDetail }
export type SolutionBranch = { id: string; label: string; children: (SolutionBranch | SolutionLeaf)[] }
export type SolutionNode = SolutionBranch | SolutionLeaf

const DETAIL: SolutionDetail = {
  title: "Active Aerogel",
  year: 2013,
  country: "Portugal",
  tag: "Funding",
  summary: "Active Aerogels is a leading company specializing in the development and production of advanced aerogel materials.",
  bullets: [
    "High absorption capacity up to 90x its weight",
    "Selective oil absorption; repels water",
    "Rapid absorption for efficient cleanup",
    "Environmentally friendly and biodegradable",
    "Reusability after oil extraction"
  ],
  paragraph: "Aerogels are available in various forms and are used in industries such as oil and gas, maritime, and environmental cleanup."
}

export const SOLUTION_TREE: SolutionNode[] = [
  {
    id: "innovative-materials",
    label: "Innovative Materials for Oil Spills",
    children: [
      {
        id: "superhydrophobic-membranes",
        label: "Superhydrophobic membranes",
        children: [
          { id: "active-aerogel", label: "Aerogels", detail: DETAIL },
          { id: "bio-inspired", label: "Bio-inspired materials", detail: { ...DETAIL, title: "Bio-inspired Material" } }
        ]
      }
    ]
  },
  {
    id: "pipeline-leak-prevention",
    label: "Pipeline Leak Prevention",
    children: [
      { id: "leak-detection", label: "Leak detection systems", detail: { ...DETAIL, title: "Leak Detection System" } },
      { id: "sealing-tech", label: "Pipeline sealing technologies", detail: { ...DETAIL, title: "Sealing Technology" } },
      { id: "stability", label: "Subsea pipeline stability improvements", detail: { ...DETAIL, title: "Stability Improvements" } }
    ]
  },
  {
    id: "oil-recovery-tech",
    label: "Oil Recovery Technologies",
    children: [
      { id: "recovery-systems", label: "Recovery systems", detail: { ...DETAIL, title: "Recovery System" } },
      { id: "oil-water-sep", label: "Oil-water separation devices", detail: { ...DETAIL, title: "Separation Device" } },
      { id: "recycling-reuse", label: "Recycling and reuse technologies", detail: { ...DETAIL, title: "Recycling & Reuse" } }
    ]
  }
]