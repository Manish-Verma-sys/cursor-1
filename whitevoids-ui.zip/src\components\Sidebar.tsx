﻿import { SolutionNode } from "../data/dummy"
type Props = { tree: SolutionNode[]; activeId: string; onSelect: (id: string) => void }
export function Sidebar({ tree, activeId, onSelect }: Props) {
  return (<ul className="list-none p-0 m-0" role="tree">
    {tree.map(n => <TreeNode key={n.id} node={n} activeId={activeId} onSelect={onSelect} depth={0} />)}
  </ul>)
}
function TreeNode({ node, activeId, onSelect, depth }:{
  node: SolutionNode; activeId: string; onSelect: (id:string)=>void; depth: number
}) {
  const isLeaf = !("children" in node)
  const isActive = node.id === activeId
  return (
    <li className="my-0.5" role="treeitem" aria-selected={isActive}>
      <div
        className={`tree-row ${isActive ? "tree-row-active" : ""}`}
        style={{ paddingLeft: `${12 + depth * 16}px` }}
        onClick={() => !isLeaf && onSelect(node.id)}
      >
        {isLeaf ? <span className="w-1.5 h-1.5 bg-slate-400 rounded-full" /> : <span className="text-slate-500">▾</span>}
        <span
          className={`select-none ${isLeaf ? "leaf-label" : ""}`}
          onClick={(e) => { e.stopPropagation(); if (isLeaf) onSelect(node.id) }}
        >{node.label}</span>
      </div>
      {"children" in node && (
        <ul className="pl-0" role="group">
          {node.children.map(c =>
            <TreeNode key={c.id} node={c} activeId={activeId} onSelect={onSelect} depth={depth + 1} />
          )}
        </ul>
      )}
    </li>
  )
}