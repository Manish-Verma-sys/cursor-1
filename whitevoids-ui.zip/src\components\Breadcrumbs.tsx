﻿type Crumb = { id: string; label: string }
type Props = { items: Crumb[]; onSelect: (id: string) => void }
export function Breadcrumbs({ items, onSelect }: Props) {
  return (
    <nav className="flex items-center gap-2 text-sm text-brand-600 mt-2" aria-label="Breadcrumb">
      <button className="hover:underline" onClick={() => onSelect(items[0]?.id ?? "")}>Problem Entry</button>
      <span className="text-slate-500">›</span>
      <button className="hover:underline" onClick={() => onSelect(items[items.length - 2]?.id ?? "")}>Solutions</button>
    </nav>
  )
}