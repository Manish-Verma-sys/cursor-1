﻿type Props = { userName: string; onToggleSidebar: () => void }
export function Header({ userName, onToggleSidebar }: Props) {
  return (
    <header className="flex items-center gap-4 px-4 py-2 bg-brand-500 text-white">
      <button
        className="md:hidden -ml-1 inline-flex items-center justify-center w-9 h-9 rounded-md bg-white/15 hover:bg-white/25"
        aria-label="Toggle menu"
        onClick={onToggleSidebar}
      >☰</button>
      <div className="flex items-center gap-2">
        <img src="https://dummyimage.com/120x40/1ab39b/ffffff&text=WHITEVOIDS" alt="Whitevoids" className="h-9" />
      </div>
      <div className="flex-1" />
      <div className="flex items-center gap-3 font-semibold">
        <span>Welcome {userName}</span>
        <div className="w-7 h-7 bg-white rounded-full" aria-hidden />
      </div>
    </header>
  )
}