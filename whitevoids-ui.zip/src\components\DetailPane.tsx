﻿import { SolutionDetail } from "../data/dummy"
export function DetailPane({ detail }: { detail: SolutionDetail }) {
  return (
    <article className="p-3 md:p-4" aria-labelledby="detail-title">
      <div className="flex flex-wrap gap-2 mb-3">
        <button className="pill">Patent Validation</button>
        <button className="pill pill-primary">Commercial Validation</button>
        <button className="pill">Major Players</button>
      </div>
      <h1 id="detail-title" className="mt-2 mb-1 text-2xl font-semibold text-emerald-800">
        {detail.title} <span className="text-sm text-slate-600 font-semibold">{detail.year} | {detail.country} | {detail.tag}</span>
      </h1>
      <p className="mt-2 mb-3">{detail.summary}</p>
      <ul className="list-disc pl-6 mb-3">{detail.bullets.map((b,i)=><li key={i}>{b}</li>)}</ul>
      <p className="mb-4">{detail.paragraph}</p>
      <div className="flex gap-2" aria-label="Pager">
        <button className="icon-btn hover:bg-brand-50" aria-label="Previous">◀</button>
        <button className="icon-btn hover:bg-brand-50" aria-label="Next">▶</button>
      </div>
    </article>
  )
}